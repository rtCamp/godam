<?php //Silence is golden
